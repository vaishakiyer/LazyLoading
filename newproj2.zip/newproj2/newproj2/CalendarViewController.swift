//
//  CalendarViewController.swift
//  newproj2
//
//  Created by Vaishak iyer on 11/01/17.
//  Copyright © 2017 Vaishak iyer. All rights reserved.
//

import UIKit
import CVCalendar


protocol DateSentDelegate {
    func dateSent(data: String)
}

class CalendarViewController: UIViewController, CVCalendarMenuViewDelegate, CVCalendarViewDelegate {
    
    
    var delegate : DateSentDelegate? = nil
    var dateString : String?
    @IBOutlet weak var menuView: CVCalendarMenuView!

    @IBOutlet weak var calendarView: CVCalendarView!
    override func viewDidLoad() {
        super.viewDidLoad()
        menuView.commitMenuViewUpdate()
        calendarView.commitCalendarViewUpdate()
        BarButton()
      

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func firstWeekday() -> Weekday
    {
        return Weekday.monday
    }
    func dayOfWeekTextColor(by weekday: Weekday) -> UIColor
    {
        return UIColor.blue
    }

    
    func shouldAutoSelectDayOnMonthChange() -> Bool
    {
        return true
    }
    func shouldScrollOnOutDayViewSelection() -> Bool
    {
        return true
    }
    func presentationMode() -> CalendarMode
    {
        let mode = CalendarMode.monthView
        return mode
    }
    func BarButton()
    {
        navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: "Cancel", style: .plain, target: self, action: #selector(CalendarViewController.dissmissController))
    }
    func dissmissController() {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    @IBAction func dateSelected(_ sender: UIButton) {
        
        if delegate != nil{
            let data = dateString
            delegate?.dateSent(data: (data)!)
           
        }
        
        
        self.dissmissController()
    
        
    }
    

    func presentedDateUpdated( _ date: CVDate) {
        //print(date.date)
        
        
        
        dateString = date.commonDescription
        
        
        
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
