//
//  CameraCollectionViewCell.swift
//  newproj2
//
//  Created by Vaishak iyer on 14/01/17.
//  Copyright © 2017 Vaishak iyer. All rights reserved.
//

import UIKit

class CameraCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var addImage: UIButton!
    
    @IBOutlet weak var photosClicked: UIImageView!
    
}
