//
//  CameraFusumaViewController.swift
//  newproj2
//
//  Created by Vaishak iyer on 15/01/17.
//  Copyright © 2017 Vaishak iyer. All rights reserved.
//

import UIKit
import Fusuma


class CameraFusumaViewController: UIViewController , FusumaDelegate{

   
    override func viewDidLoad() {
        super.viewDidLoad()
    fusumaImplement()
        // Do any additional setup after loading the view.
    }
    
    func fusumaImplement(){
        let fusuma = FusumaViewController()
        fusuma.delegate = self
        fusuma.hasVideo = true // If you want to let the users allow to use video.
        self.present(fusuma, animated: true, completion: nil)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   func fusumaImageSelected(_ image: UIImage, source: Fusuma.FusumaMode)
   {
       
    }
    // Return the image but called after is dismissed.
    public func fusumaDismissedWithImage(_ image: UIImage, source: Fusuma.FusumaMode)
    {
        
    }
    
     public func fusumaVideoCompleted(withFileURL fileURL: URL)
     {
        
    }
    // When camera roll is not authorized, this method is called.
     func fusumaCameraRollUnauthorized()
     {
        
    }
    
    func fusumaClosed()
    {
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
