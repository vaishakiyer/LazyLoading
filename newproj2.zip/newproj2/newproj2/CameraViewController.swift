//
//  CameraViewController.swift
//  newproj2
//
//  Created by Vaishak iyer on 14/01/17.
//  Copyright © 2017 Vaishak iyer. All rights reserved.
//

import UIKit



class CameraViewController: UIViewController, UICollectionViewDelegate,UICollectionViewDataSource,UIImagePickerControllerDelegate, UINavigationControllerDelegate

{
    
    var fab: MIFab!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        // Do any additional setup after loading the view.
    }
    
    
    
       
    
    

    @IBOutlet var actionPressed: UIButton!
    @IBAction func savePressed(_ sender: UIBarButtonItem) {
        
        let imageData = UIImageJPEGRepresentation(photoStored[selectedIndex], 0.6)
        
        let compressedJPGImage = UIImage(data: imageData!)
        UIImageWriteToSavedPhotosAlbum(compressedJPGImage!, nil, nil, nil)
        
       let alert =  UIAlertAction(title: "It has ben Saved", style: .default)
        
        
        alertController.addAction(alert)
    }
    
    @IBOutlet weak var cameraCollectionView: UICollectionView!
    
    var photoStored = [UIImage]()
    
    var imagePicker = UIImagePickerController()
    
    var selectedIndex : Int = 0
    
    let alertController = UIAlertController()
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return  photoStored.count + 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        
        let cell = cameraCollectionView.dequeueReusableCell(withReuseIdentifier: "cameraCell", for: indexPath) as! CameraCollectionViewCell
        
        
        
        
        cell.addImage.addTarget(self, action: #selector(CameraViewController.whenPlusButtonPressed), for: .touchUpInside)
        
//        cell.addImage.imageView?.image = photoStored[indexPath.row]
        
       

      
        return cell
        
    }
    
    

    
    
    func whenPlusButtonPressed(){
        
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            
            
            let cameraAction = UIAlertAction(title: "Take the Photo", style: .default){
                (action) in
                self.imagePicker.sourceType = .camera
                self.imagePicker.delegate = self

                self.present(self.imagePicker, animated: true, completion: nil)
            }
            alertController.addAction(cameraAction)
        }
        
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let photosLibraryAction = UIAlertAction(title: "Pick image", style: .default) { (action) in
                self.imagePicker.sourceType = .photoLibrary
                self.selectedIndex = 1
                self.present(self.imagePicker, animated: true, completion: nil)
                
            }
            alertController.addAction(photosLibraryAction)
        
        
    
    }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
        {
          
           
            if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage{
                
               
                             photoStored.append(pickedImage)
                cameraCollectionView.reloadData()
                
                
            }
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
}
