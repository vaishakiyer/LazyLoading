//
//  ExpandTableViewCell.swift
//  newproj2
//
//  Created by Vaishak iyer on 17/01/17.
//  Copyright © 2017 Vaishak iyer. All rights reserved.
//

import UIKit

class ExpandTableViewCell: UITableViewCell {

    @IBOutlet weak var imageGiven: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
