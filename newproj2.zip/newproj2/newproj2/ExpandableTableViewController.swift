//
//  ExpandableTableViewController.swift
//  newproj2
//
//  Created by Vaishak iyer on 17/01/17.
//  Copyright © 2017 Vaishak iyer. All rights reserved.
//

import UIKit

class ExpandableTableViewController: UITableViewController {

    @IBOutlet var expandableCell: UITableView!
    var expandableImage : UIImageView!
   
    var indexOfCell : Int = 0
    var heightOfRow :CGFloat = 200
    
    var ischeck : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
            switch section{
                
            case 0:
                
                return 1
                
            default:
                
                return 1
                
            }
        
        
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.section{
            
        case 0:
            
            let cell = expandableCell.dequeueReusableCell(withIdentifier: "cell1" , for: indexPath) as! ExpandTableViewCell
            
            let tap = UITapGestureRecognizer(target: self, action: #selector(ExpandableTableViewController.expandCell(sender:)))
            
            cell.imageGiven.addGestureRecognizer(tap)
            cell.imageGiven.isUserInteractionEnabled = true
          return cell
        
        default:
            
            let cell = expandableCell.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! ExpandTableViewCell
            
            cell.textLabel?.text = "Vaishak"
            return cell
        }
      

        

      
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        switch indexPath.section{
        case 0:
            return heightOfRow
        
        case 1:
            return 200
        default:
            
            return 200
        }
        
    }
    
    func expandCell(sender: UITapGestureRecognizer)
    {
//        let image = sender.view as! UIImageView
//        
//        let cell = expandableCell.cellForRow(at: IndexPath(row: image.tag, section: 0)) as! ExpandTableViewCell
      
        ischeck = !ischeck
        
        if ischeck{
            heightOfRow = 400
        }else
        {
            heightOfRow = 200
        }
        
        
        expandableCell.reloadData()
//        expandableImage.image = cell.imageGiven.image
//        
//        expandableCell.reloadRows(at: [IndexPath(row: image.tag, section: 0)], with: .fade)
//        expandableCell.scrollToRow(at: IndexPath(row: image.tag, section: 0), at: .top, animated: true)
        
        
        
        
    }
    
     override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
     {
        switch section{
        case 0:
            return "ImageDetail"
            
        default:
            
            return "DummyData"
        }
    }
   


    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


}
