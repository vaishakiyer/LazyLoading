//
//  ImplementWebViewController.swift
//  Pods
//
//  Created by Vaishak iyer on 16/01/17.
//
//

import UIKit


class ImplementWebViewController: UIViewController, UIWebViewDelegate {
    @IBOutlet weak var fBWebView: UIWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let requestURL = NSURL(fileURLWithPath: "https://www.facebook.com/")
  self.fBWebView.delegate = self
//        let request = NSURLRequest(url: requestURL as URL)
        
        fBWebView.loadRequest(NSURLRequest(url: NSURL(string: "https://www.facebook.com/")! as URL) as URLRequest)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func webViewDidStartLoad(_ webView: UIWebView)
    {
        
    }
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        
    }
     func webView(_ webView: UIWebView, didFailLoadWithError error: Error)
     {
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
