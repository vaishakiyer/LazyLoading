//
//  MoreInfoViewController.swift
//  newproj2
//
//  Created by Vaishak iyer on 11/01/17.
//  Copyright © 2017 Vaishak iyer. All rights reserved.
//

import UIKit
import Alamofire
import Kingfisher

class MoreInfoViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, DateSentDelegate{

    @IBOutlet weak var heightOfTextBox: NSLayoutConstraint!
    @IBOutlet weak var showLabel: UILabel!
    @IBOutlet weak var dateSelected: UILabel!
    @IBOutlet weak var movieImg: UIImageView!
    @IBOutlet weak var calendarButton: UIButton!
    @IBOutlet weak var showPicker: UIPickerView!
    @IBOutlet weak var descT: UILabel!
    @IBOutlet weak var movieT: UILabel!
    @IBOutlet weak var descriptionOfMovie: UITextView!
    var ischecked : Bool = true
    @IBOutlet weak var launchShowTiming: UIButton!
    let showData = ["Show1","Show2","Show3","Show4"]
    var movie : NSDictionary = [:]
    let alertController = UIAlertController()
        override func viewDidLoad() {
        super.viewDidLoad()
    updateParameter()
            
       self.showPicker.dataSource = self
       self.showPicker.delegate = self
       showPicker.isHidden = true
           
 
          
            
            
        // Do any additional setup after loading the view.
    }

    @IBAction func clickedCalender(_ sender: UIButton, forEvent event: UIEvent) {
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "CalendarViewController") as! CalendarViewController
        let nc = UINavigationController.init(rootViewController: controller)
        controller.delegate = self
       
        self.present(nc, animated: true, completion: nil)
        
        
        
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showSelect(_ sender: UIButton) {
        
       ischecked = !ischecked
        
        if ischecked{
        showPicker.isHidden = false
        }else
        {
            showPicker.isHidden = true
        }
      
    }
    
    func updateParameter()
    {
      movieT.text = movie["Title"] as? String
       descriptionOfMovie.text = movie["Intro"] as? String
        
        let movieI = movie["Photo"]
        
        movieImg.kf.setImage(with: URL(string: movieI as! String) as Resource?)
        
        let intToStr = movie["Running time"]
        descT.text = String(describing: intToStr!)
        

    }
    
    func increaseTextBoxSize()
    {
        
        
    }
    
   
   
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return showData.count
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        
        return showData[row]
        
    }
    
     func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
     {
        showLabel.text = showData[row]
        showPicker.isHidden = true
        
        
    }
    
    func dateSent(data: String) {
        
        dateSelected.text = data
        
        
    }
    
    @IBAction func expandTextBox(_ sender: UIButton) {
        
        ischecked = !ischecked
        
        if ischecked{
            heightOfTextBox.constant = 400
            
        }else
        {
            heightOfTextBox.constant = 194
        }
    }
    
    @IBAction func bookPressed(_ sender: Any) {
        
        let press = UIAlertAction(title: "Thank You for booking with us", style: .default, handler: nil)
        
        alertController.addAction(press)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
