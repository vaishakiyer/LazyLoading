//
//  MovieTableViewCell.swift
//  newproj2
//
//  Created by Vaishak iyer on 11/01/17.
//  Copyright © 2017 Vaishak iyer. All rights reserved.
//

import UIKit
import Cosmos


class MovieTableViewCell: UITableViewCell {
    @IBOutlet weak var movieImageLoad: UIImageView!
    @IBOutlet weak var movieName: UILabel!
    @IBOutlet weak var movieRunTime: UILabel!

    @IBOutlet weak var movieRating: CosmosView!
    @IBOutlet weak var bookButton: UIButton!
    @IBOutlet weak var moreInfoPressed: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    

}
