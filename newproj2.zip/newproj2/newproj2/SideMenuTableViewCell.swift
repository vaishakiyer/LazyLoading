//
//  SideMenuTableViewCell.swift
//  newproj2
//
//  Created by Vaishak iyer on 13/01/17.
//  Copyright © 2017 Vaishak iyer. All rights reserved.
//

import UIKit

class SideMenuTableViewCell: UITableViewCell {
    @IBOutlet weak var sideMenuText: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
