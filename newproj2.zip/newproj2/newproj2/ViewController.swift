//
//  ViewController.swift
//  newproj2
//
//  Created by Vaishak iyer on 11/01/17.
//  Copyright © 2017 Vaishak iyer. All rights reserved.
//

import UIKit
import Alamofire
import Cosmos
import Kingfisher




class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource

{
    
    @IBOutlet weak var widthControl: NSLayoutConstraint!
    @IBOutlet weak var taskTableView: UITableView!
   
   
    @IBOutlet weak var movieTableView: UITableView!
    var ischeck : Bool = false
     var movies = [[String: AnyObject]]()
    var Tasks = ["Task1","Task2","Task3","Task4"]
   var alert = UIAlertController()
    override func viewDidLoad() {
        super.viewDidLoad()
       widthControl.constant = 0
        movieTableView.allowsMultipleSelectionDuringEditing = true
        movieTableView.setEditing(true, animated: true)
      sideMenubutton()
        
        
        let url = URL(string: "http://sweettutos.com/movies.json")
        
        Alamofire.request(url!, method: .post, parameters: ["foo": "bar"], encoding: JSONEncoding.default)
            
            .responseJSON { response in
                
                print(response)
                
                
                
                if let result = response.result.value {
                    
                    let JSON = result as! Dictionary<String, AnyObject>
                    
                    
                    
                    self.movies = JSON["movies"] as! [[String : AnyObject]]!
                    
                    DispatchQueue.main.async(execute: {
                        
                        self.movieTableView.reloadData()
                        
                    })
                    
                }
          
                
                
                
                
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == taskTableView{
         return Tasks.count
        }else {
          return  movies.count
        }
        
        
        
        }
    func morePressed(_ sender: UIButton?) {
        print( sender?.tag ?? 3)
        
        
        let toGoController = self.storyboard?.instantiateViewController(withIdentifier: "MoreInfoViewController") as! MoreInfoViewController
        
        toGoController.movie = movies[(sender?.tag)!] as NSDictionary
        
        self.navigationController?.pushViewController(toGoController, animated: true)
        
        
        
        
        
    }
    
    func sideMenubutton()
    {
        navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: "Side", style: .plain, target: self, action: #selector(ViewController.sideMenuTransition))
        
    }
    
    func sideMenuTransition()
    {
        ischeck = !ischeck
        
        
        if ischeck{
            
            widthControl.constant = 240
            
        }else{
            
            widthControl.constant = 0
            
        }
        
        
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        if tableView == taskTableView
        {
            let  cell1 = taskTableView.dequeueReusableCell(withIdentifier: "taskCell") as! SideMenuTableViewCell
            
            cell1.sideMenuText.text = Tasks[indexPath.row]
            return cell1
        }else{
            let cell = movieTableView.dequeueReusableCell(withIdentifier: "movieCell") as! MovieTableViewCell
            let movie = self.movies[indexPath.row]
            let title = movie["Title"]
            let runTime = movie["Running time"]
            let movieImage = movie["Photo"]
            cell.movieName.text = title as! String?
            cell.movieRunTime.text = String(describing: runTime!) as String?
            cell.movieImageLoad.layer.cornerRadius = 30
            cell.movieImageLoad.clipsToBounds = true
            cell.movieImageLoad.kf.setImage(with: URL(string: movieImage as! String) as Resource?)
            cell.movieRating.rating = 4
            cell.movieRating.settings.updateOnTouch = false
            cell.moreInfoPressed.tag = indexPath.row
            cell.moreInfoPressed.addTarget(self, action: #selector(ViewController.morePressed(_:)), for: .touchUpInside)
            
            
//            let selectedIndexPaths = tableView.indexPathsForSelectedRows
//            let rowIsSelected = selectedIndexPaths != nil && selectedIndexPaths!.contains(indexPath)
//            cell.accessoryType = rowIsSelected ? .checkmark : .none
            
            
            return cell
            
            
            
            
        
        }
    }
    
    
    
//     func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
//        let cell = movieTableView.cellForRow(at: indexPath)!
//        cell.accessoryType = .none
//        // cell.accessoryView.hidden = true  // if using a custom image
//    }
    
       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       
        if tableView == taskTableView{
            
            switch indexPath.row
            {
            case 0 :
                
                widthControl.constant = 0
            case 1 :
                
                let controller = self.storyboard?.instantiateViewController(withIdentifier: "CameraViewController") as! CameraViewController
                
                self.navigationController?.pushViewController(controller, animated: true)
                
            case 2 :
                
                let controller = self.storyboard?.instantiateViewController(withIdentifier: "ImplementWebViewController") as! ImplementWebViewController
                
                self.navigationController?.pushViewController(controller, animated: true)
                
            case 3 :
                
                let controller = self
                    .storyboard?.instantiateViewController(withIdentifier: "ExpandableTableViewController") as! ExpandableTableViewController
                
                self.navigationController?.pushViewController(controller, animated: true)
                
            default:
                
                break
                
                
            }
        }
//        }else{
//            
//            let cell = movieTableView.cellForRow(at: indexPath)!
//            cell.accessoryType = .checkmark
//        }
        
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]?
    {
        
        let bookAction = UITableViewRowAction(style: .default, title: "Book", handler: { (action, indexPath) in
            let action = UIAlertAction(title: "Thank you for booking", style: .default, handler: nil)
            self.alert.addAction(action)
            self.present(self.alert, animated: true, completion: nil)
            
        })
        bookAction.backgroundColor = UIColor.blue
        
      
        return [bookAction]
        
        
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        return true
    }
    
       

   

        
}

    
    
    
    
       
    

    





